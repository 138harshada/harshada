package com.genericlibrary;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebElement;


public class commonlibrary {

	public void normalwait(long duration) {
		try {
			Thread.sleep(duration);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@SuppressWarnings("deprecation")
	public void pagetoLoad(long duration) {
		Browser.driver.manage().timeouts().implicitlyWait(duration, TimeUnit.SECONDS);
	}
	
	
	public void acceptalert() {
		Alert alt=Browser.driver.switchTo().alert();
		alt.accept();
	}
	public void cancelalert() {
		Alert alt=Browser.driver.switchTo().alert();
		alt.dismiss();
	}
	public String alertText() {
		Alert alt=Browser.driver.switchTo().alert();
		String text=alt.getText();
		return text;
	}
	
	public void handleframe(int frameindex) {
	Browser.driver.switchTo().frame(frameindex);
	}
	public void handleframe(String Framevalue) {
		Browser.driver.switchTo().frame(Framevalue);
		}
	
	public void handleframe(WebElement wb) {
		Browser.driver.switchTo().frame(wb);
		}
	
	public boolean verifytext(WebElement wb,String ExpectedResult) {
		
		String actualresult=wb.getText();
		boolean status=false;
		if(actualresult.equals(ExpectedResult)) {
			status=true;
			System.out.println("Test is passed==Pass");
		}else {
			System.out.println("Test is failed==fail");
		}
		
		return status;	
	}
	
	
	public String gettitleofpages() {
		String title=Browser.driver.getTitle();
		return title;
	}
	
	
}
