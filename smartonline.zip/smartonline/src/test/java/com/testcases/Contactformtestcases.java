package com.testcases;

import org.openqa.selenium.By;

import org.openqa.selenium.JavascriptExecutor;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.PageFactory;

import org.openqa.selenium.support.ui.ExpectedConditions;

import org.testng.Assert;

import org.testng.annotations.AfterMethod;

import org.testng.annotations.BeforeClass;

import org.testng.annotations.BeforeMethod;

import org.testng.annotations.Test;

import com.genericlibrary.Browser;

import com.genericlibrary.Propertiesfile;

import com.genericlibrary.commonlibrary;

import com.pageobject.ContactPageObject;

public class Contactformtestcases extends commonlibrary {

WebDriver driver;

ContactPageObject contactpage;

@BeforeClass

public void bfrcls() {

driver= Browser.get_browser();

}

@BeforeMethod

public void bfrmtd() {

driver.get(Propertiesfile.URL);;

driver.manage().window().maximize();

contactpage=PageFactory.initElements(driver, ContactPageObject.class);

}

@Test

public void Contactformtest() throws InterruptedException {

String title= gettitleofpages();

Assert.assertEquals(title,"Home - Great Finance");

contactpage.Clickoncontacts();

String contactstitle= gettitleofpages();

Assert.assertEquals(contactstitle,"Contact - Great Finance");

String headercontacts=contactpage.contactsheadertext();

Assert.assertEquals(headercontacts, "CONTACT");

driver.findElement(By.name("input_19")).sendKeys("Harshada");

driver.findElement(By.name("input_18")).sendKeys("Sonawane");

driver.findElement(By.name("input_7")).sendKeys("harshada.sonawane@invezza.com");

driver.findElement(By.name("input_8")).sendKeys("9890470558");

driver.findElement(By.name("input_5")).sendKeys("i am good");

driver.findElement(By.xpath("//input[@id='gform_submit_button_29']")).click();

// clicking on facebook link

WebElement ele = driver.findElement(By.xpath("//span[.='Join us on Facebook']"));

JavascriptExecutor jse = (JavascriptExecutor)driver;

jse.executeScript("arguments[0].click()", ele);

//Assert.assertTrue(ExpectedConditions.titleContains("AFGAustralianFinanceGroup").apply(driver).booleanValue());

System.out.println("Page title is : " + driver.getTitle());

driver.switchTo().defaultContent();

Thread.sleep(3000);

//clicking on twitter link

WebElement st = driver.findElement(By.xpath("//span[.='Join us on Twitter']"));

JavascriptExecutor jse1 = (JavascriptExecutor)driver;

jse1.executeScript("arguments[0].click()", st);

System.out.println("Page title is : " + driver.getTitle());

Thread.sleep(3000);

}


@AfterMethod

public void aftmtd() {

driver.quit();

}

}