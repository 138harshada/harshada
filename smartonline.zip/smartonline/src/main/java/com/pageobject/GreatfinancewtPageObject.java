package com.pageobject;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class GreatfinancewtPageObject {
@FindBy(xpath = "//li[@id='menu-item-102']/a")		
private WebElement About_link;
@FindBy(xpath = "//li[@id='menu-item-1087']/a")
private WebElement Home_loanlink;
@FindBy(xpath = "//li[@id='menu-item-1093']/a")
private WebElement Business_loanlink;
@FindBy(xpath = "//li[@id='menu-item-37646']/a")
private WebElement Testpagefromdianalink;
@FindBy(xpath = "//li[@id='menu-item-36564']/a")
private WebElement  Calculatorlink;
@FindBy(xpath = "//li[@id='menu-item-273']/a")
private WebElement  Tipsandguidelink;
@FindBy(xpath = "//li[@id='menu-item-276']/a")
private WebElement  Newslink;
@FindBy(xpath = "//li[@id='menu-item-204']/a")
private WebElement  contactslink;

@FindBy(xpath = "//div[@class='wpb_wrapper']/span/span")
private WebElement home_loanHeader;

@FindBy(xpath= "//div[@class='wpb_wrapper']/span")
private WebElement business_loanHeader;

@FindBy(xpath="//h2[@class='vc_custom_heading']")
private WebElement textpage_Header;

@FindBy(xpath="//div[@class='wpb_wrapper']/span/span")
private WebElement calculators_Header;

@FindBy(xpath="//div[@class='wpb_wrapper']/span")
private WebElement contacts_header;


public void clickonabout() {
	About_link.click();
}
public void clikonhomeloan() {
	Home_loanlink.click();
}

public void Clickonbusinessloan() {
	Business_loanlink.click();
}

public void Clickontestpageform() {
	Testpagefromdianalink.click();
}
public void Clickoncalculator() {
	Calculatorlink.click();
}

public void Clickonnews() {
	Newslink.click();
}
public void Clickoncontacts() {
	contactslink.click();
}
public String homeloanheadertext() {
String text	=home_loanHeader.getText();
return text;
}
public String businessloneheadertext() {
	String text = business_loanHeader.getText();
	return text;
}
public String testpageheadertext() {
	String text = textpage_Header.getText();
	return text;
}
public String calculatersheadertext() {
	String text = calculators_Header.getText();
	return text;
}

public String contactsheadertext() {
	String text = contacts_header.getText();
	return text;
	
}


}
