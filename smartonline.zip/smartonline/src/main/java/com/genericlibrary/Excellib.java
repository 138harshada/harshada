package com.genericlibrary;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class Excellib {

	String filepath="C:\\Users\\HP\\Desktop\\CreateCustomer.xlsx";
	
	public String ReadExcelStringData(String Sheetname,int row,int colnum) throws EncryptedDocumentException, IOException {
		FileInputStream fis=new FileInputStream(filepath);
		Workbook wb=WorkbookFactory.create(fis);
		Sheet sh=wb.getSheet(Sheetname);
	  Row rw=sh.getRow(row);
	String data=rw.getCell(colnum).getStringCellValue();
	return data;
	}
	public double ReadExcelNumericData(String Sheetname,int row,int colnum) throws EncryptedDocumentException, IOException {
		FileInputStream fis=new FileInputStream(filepath);
		Workbook wb=WorkbookFactory.create(fis);
		Sheet sh=wb.getSheet(Sheetname);
	  Row rw=sh.getRow(row);
	double data=rw.getCell(colnum).getNumericCellValue();
	return data;
	}
	
	public int GetLastrowNumber(String Sheetname,int row,int colnum) throws EncryptedDocumentException, IOException {
		FileInputStream fis=new FileInputStream(filepath);
		Workbook wb=WorkbookFactory.create(fis);
		Sheet sh=wb.getSheet(Sheetname);
	      int rowcount= sh.getLastRowNum();
	      return rowcount;
	}
	public void WriteExcelData(String Sheetname,int row,int colnum,String data) throws EncryptedDocumentException, IOException {
		FileInputStream fis=new FileInputStream(filepath);
		Workbook wb=WorkbookFactory.create(fis);
		Sheet sh=wb.getSheet(Sheetname);
	    Row rw=sh.getRow(row);
	    Cell cel= rw.createCell(colnum);
	    cel.setCellType(CellType.STRING);
	    FileOutputStream fos=new FileOutputStream(filepath);
	    cel.setCellValue(data);
	    wb.write(fos);
	    wb.close();
	}
	
	
}
