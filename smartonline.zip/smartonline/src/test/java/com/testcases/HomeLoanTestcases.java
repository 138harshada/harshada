package com.testcases;

import java.util.ArrayList;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import org.openqa.selenium.support.ui.ExpectedConditions;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import com.genericlibrary.Browser;
import com.genericlibrary.Propertiesfile;

public class HomeLoanTestcases {
WebDriver driver;
//GreatfinancewtPageObject greatfinacepage;

@BeforeClass
public void bfrcls() {
driver= Browser.get_browser();
}

@BeforeMethod
 public void bfrmtd() {
driver.get(Propertiesfile.URL);;
driver.manage().window().maximize();
//greatfinacepage=PageFactory.initElements(driver, GreatfinancewtPageObject.class);
}

//@SuppressWarnings("unused")
@Test
//HomeLoan-contact page
public void HomeLoancontactpageTestthrowsInterruptedException() throws InterruptedException{
  driver.findElement(By.xpath("//a[@class='sf-with-ul'][normalize-space()='Home Loans']")).click();
  driver.findElement(By.xpath("//span[normalize-space()='Contact us now']")).click();
  driver.findElement(By.name("input_19")).sendKeys("harshada");
  driver.findElement(By.name("input_18")).sendKeys("Sonawane");
  driver.findElement(By.name("input_7")).sendKeys("harshadasonawane138@gmail.com");
  driver.findElement(By.name("input_8")).sendKeys("9890470558");
  driver.findElement(By.name("input_5")).sendKeys("I Want a emi option");
  driver.findElement(By.xpath("//input[@id='gform_submit_button_29']")).click();}

//click on facebook
  @Test
  public void HomeLoanFacebookTestthrowsInterruptedException() throws InterruptedException{
	  driver.findElement(By.xpath("//a[@class='sf-with-ul'][normalize-space()='Home Loans']")).click();
  WebElement ele = driver.findElement(By.xpath("//span[normalize-space()='Join us on Facebook']"));
  JavascriptExecutor jse = (JavascriptExecutor)driver;
  jse.executeScript("arguments[0].click()", ele);
//Assert.assertTrue
  ExpectedConditions.titleContains("AFGAustralianFinanceGroup").apply(driver).booleanValue();
  System.out.println("Page title is : " + driver.getTitle());
  driver.switchTo().defaultContent();
  Thread.sleep(4000);}
 
//clicking on twitter link
  @Test
  public void HomeLoantwitterTestthrowsInterruptedException() throws InterruptedException{
	  driver.findElement(By.xpath("//a[@class='sf-with-ul'][normalize-space()='Home Loans']")).click();
  WebElement st = driver.findElement(By.xpath("//span[normalize-space()='Join us on Twitter']"));
  JavascriptExecutor jse1 = (JavascriptExecutor)driver;
  jse1.executeScript("arguments[0].click()", st);
  System.out.println("Page title is : " + driver.getTitle());
  Thread.sleep(4000);
 
//close multiple windows and switch to parent window
  String originalHandle = driver.getWindowHandle();
  for(String handle : driver.getWindowHandles()) {
  if (!handle.equals(originalHandle)) {
  driver.switchTo().window(handle);
  driver.close();
 }
 }
  driver.switchTo().window(originalHandle);
  }
  
//click on home link-speak us to today
  @Test
  public void HomeLoanspeakustodayTestthrowsInterruptedException() throws InterruptedException{
  driver.findElement(By.xpath("//a[@class='sf-with-ul'][normalize-space()='Home Loans']")).click();
  driver.findElement(By.xpath("//span[normalize-space()='Speak To Us Today']")).click();
  driver.findElement(By.name("input_19")).sendKeys("harshada");
  driver.findElement(By.name("input_18")).sendKeys("Sonawane");
  driver.findElement(By.name("input_7")).sendKeys("harshadasonawane138@gmail.com");
  driver.findElement(By.name("input_8")).sendKeys("9890470558");
  driver.findElement(By.name("input_5")).sendKeys("I Want a emi option");
  driver.findElement(By.xpath("//input[@id='gform_submit_button_29']")).click();
  
//close multiple windows and switch to parent window
  String originalHandle1 = driver.getWindowHandle();
  for(String handle : driver.getWindowHandles()) {
  if (!handle.equals(originalHandle1)) {
  driver.switchTo().window(handle);
  driver.close();
 }
 }
  driver.switchTo().window(originalHandle1); Thread.sleep(3000);}
 
//homeloan dropdown
  @Test
  public void buyinghomeTestthrowsInterruptedException() throws InterruptedException{
  Actions actions = new Actions(driver);
// home loan ka xpath
  WebElement menu=driver.findElement(By.xpath("//li[@id='menu-item-1087']/a"));
  actions.moveToElement(menu);
//menu xpath
  WebElement subMenu =driver.findElement(By.xpath("(//a[contains(text(),'Buying a Home')])[1]"));
  actions.moveToElement(subMenu); actions.click().build().perform();
  Thread.sleep(3000);}
 
 // click on facebook ((buyinghome)
  @Test
  public void buyinghomefacebookTestthrowsInterruptedException() throws InterruptedException{
  WebElement ele1 =driver.findElement(By.xpath("//span[normalize-space()='Join us on Facebook']"));
  JavascriptExecutor jse2 = (JavascriptExecutor)driver; //(create refrance)
  jse2.executeScript("arguments[0].click()", ele1);
 
//Assert.assertTrue(ExpectedConditions.titleContains("AFGAustralianFinanceGroup").apply(driver).booleanValue());
   System.out.println("Page title is : " + driver.getTitle());
   driver.switchTo().defaultContent();
   Thread.sleep(3000);}
 
//clicking on twitter link (buyinghome)
  @Test
  public void buyinghometwitterTestthrowsInterruptedException() throws InterruptedException{
  WebElement st1 = driver.findElement(By.xpath("//span[normalize-space()='Join us on Twitter']"));
 JavascriptExecutor jse3 = (JavascriptExecutor)driver;
  jse3.executeScript("arguments[0].click()", st1);
  System.out.println("Page title is : " + driver.getTitle());
  Thread.sleep(3000);

//close multiple windows and switch to parent window
  String originalHandle11 = driver.getWindowHandle();
  for(String handle : driver.getWindowHandles()) {
  if (!handle.equals(originalHandle11)) {
 
  driver.switchTo().window(handle);
 
  driver.close();
 }
 }
 driver.switchTo().window(originalHandle11);
 Thread.sleep(3000);}
 
//contact us(byinghome)
  @Test
  public void buyinghomecontactusTestthrowsInterruptedException() throws InterruptedException{
  driver.findElement(By.xpath("//a[@class='sf-with-ul'][normalize-space()='Home Loans']")).click();
  driver.findElement(By.xpath("//span[normalize-space()='Contact us now']")).click();
  driver.findElement(By.name("input_19")).sendKeys("harshada");
  driver.findElement(By.name("input_18")).sendKeys("Sonawane");
  driver.findElement(By.name("input_7")).sendKeys("harshadasonawane138@gmail.com");
  driver.findElement(By.name("input_8")).sendKeys("9890470558");
  driver.findElement(By.name("input_5")).sendKeys("I Want a emi option");
  driver.findElement(By.xpath("//input[@id='gform_submit_button_29']")).click();
  Thread.sleep(3000);}
/*
* String originalHandle111 = driver.getWindowHandle(); for(String handle :
* driver.getWindowHandles()) { if (!handle.equals(originalHandle111)) {
* driver.switchTo().window(handle);
*
* driver.close(); } } driver.switchTo().window(originalHandle111);
*/
 
//Buying a Homes Click on "Home" link
  @Test
  public void buyinghomehomeloanlinkTestthrowsInterruptedException() throws InterruptedException{
   Actions actions1 = new Actions(driver);
// home loan ka xpath
   WebElement menu1=driver.findElement(By.xpath("//li[@id='menu-item-1087']/a"));
   actions1.moveToElement(menu1);
//menu xpath
   WebElement subMenu1 =driver.findElement(By.xpath("(//a[contains(text(),'Buying a Home')])[1]"));
   actions1.moveToElement(subMenu1); actions1.click().build().perform();
   Thread.sleep(3000);
  }
//Opening each link below in new tabs
// Keys.Chord string
  @Test
  public void buyinghomelinksTestthrowsInterruptedException() throws InterruptedException{
   String clicklnk = Keys.chord(Keys.CONTROL,Keys.ENTER);
   driver.findElement(By.xpath("//a[@href='/different-loan-types/']")).sendKeys(clicklnk);
   driver.findElement(By.xpath("//a[contains(text(),'online calculators')]")).sendKeys(clicklnk);
   driver.findElement(By.xpath("//a[contains(text(),'give us a call or email us')]")).sendKeys(clicklnk);
   Thread.sleep(5000);
//store window handle ids
   ArrayList<String> w = new ArrayList<String>(driver.getWindowHandles());
//switch to open tabs
   driver.switchTo().window(w.get(1));
   System.out.println("New tab title: " + driver.getTitle());
   Thread.sleep(5000);
   driver.switchTo().window(w.get(2));
   System.out.println("New tab title: " + driver.getTitle());
   Thread.sleep(5000);
   driver.switchTo().window(w.get(3));
   System.out.println("New tab title: " + driver.getTitle());
   Thread.sleep(5000);
//switch to first tab
   driver.switchTo().window(w.get(0));
   System.out.println("First tab title: " + driver.getTitle());
   Thread.sleep(3000);

 //  driver.findElement(By.xpath("//span[contains(text(),'Speak to us today')]")).click();
 //  System.out.println("Page title is : " + driver.getTitle());
 //  Thread.sleep(5000);//



  }

}
