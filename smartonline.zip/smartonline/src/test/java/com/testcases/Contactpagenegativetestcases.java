package com.testcases;
import java.util.ArrayList;

import org.openqa.selenium.By;

	import org.openqa.selenium.JavascriptExecutor;

	import org.openqa.selenium.WebDriver;

	import org.openqa.selenium.WebElement;

	import org.openqa.selenium.support.PageFactory;

	import org.openqa.selenium.support.ui.ExpectedConditions;

	import org.testng.Assert;

	import org.testng.annotations.AfterMethod;

	import org.testng.annotations.BeforeClass;

	import org.testng.annotations.BeforeMethod;

	import org.testng.annotations.Test;

	import com.genericlibrary.Browser;

	import com.genericlibrary.Propertiesfile;

	import com.pageobject.ContactPageObject;

	public class Contactpagenegativetestcases {


	WebDriver driver;

	ContactPageObject contactpage;

	@BeforeClass

	public void bfrcls() {

	driver= Browser.get_browser();

	}

	@BeforeMethod

	public void bfrmtd() {

	driver.get(Propertiesfile.URL);;

	driver.manage().window().maximize();

	contactpage=PageFactory.initElements(driver, ContactPageObject.class);

	}

	@Test
	public void  contactpageTC1() throws InterruptedException {
	
		driver.findElement(By.xpath("//li[@id='menu-item-204']")).click();
		
		driver.findElement(By.id("input_29_19")).sendKeys("123456");
		driver.findElement(By.id("input_29_18")).sendKeys("5689034");
		driver.findElement(By.id("input_29_7")).sendKeys("harshadasonawane138@gmail.com");
		driver.findElement(By.id("input_29_8")).sendKeys("abcdefg");
		driver.findElement(By.id("input_29_5")).sendKeys("heare your project");
		driver.findElement(By.id("gform_submit_button_29")).click();
		System.out.println("Page title is : There was a problem with your submission. Please review the fields below" + driver.getTitle());
		  Thread.sleep(5000);
	}

	@Test
	public void contactpageTC2() throws InterruptedException {
        driver.findElement(By.xpath("//li[@id='menu-item-204']")).click();
		driver.findElement(By.id("input_29_19")).sendKeys("123456");
		driver.findElement(By.id("input_29_18")).sendKeys("5689034");
		driver.findElement(By.id("input_29_7")).sendKeys("afg@23");
		driver.findElement(By.id("input_29_8")).sendKeys("abcdefg");
		driver.findElement(By.id("input_29_5")).sendKeys("heare your project");
		driver.findElement(By.id("gform_submit_button_29")).click();
		System.out.println("Page title is : The email address entered is invalid, please check the formatting" + driver.getTitle());
		  Thread.sleep(5000);
	}
	
	@Test
	public void contactpageTC3() throws InterruptedException{
		
		 driver.findElement(By.xpath("//li[@id='menu-item-204']")).click();
			driver.findElement(By.id("input_29_19")).sendKeys("harshada");
			driver.findElement(By.id("input_29_18")).sendKeys("sonawane");
			driver.findElement(By.id("input_29_7")).sendKeys("harshadasonawane138@gmail.com");
			driver.findElement(By.id("input_29_8")).sendKeys("9890470558");
			driver.findElement(By.id("input_29_5")).sendKeys("heare your project");
			driver.findElement(By.id("gform_submit_button_29")).click();
			System.out.println("Page title is : The reCAPTCHA was invalid. Go back and try it again" + driver.getTitle());
			  Thread.sleep(5000);
	}
	
	@Test()
	public void contactpageTC4() throws InterruptedException{
		
		 driver.findElement(By.xpath("//li[@id='menu-item-204']")).click();
			driver.findElement(By.id("input_29_19")).sendKeys("harshada");
			driver.findElement(By.id("input_29_18")).sendKeys("sonawane");
			driver.findElement(By.id("input_29_7")).sendKeys("harshadasonawane138@gmail.com");
			driver.findElement(By.id("input_29_8")).sendKeys("9890470558");
			driver.findElement(By.id("input_29_5")).sendKeys(" ");
			driver.findElement(By.id("gform_submit_button_29")).click();
			System.out.println("Page title is : There was a problem with your submission. Please review the fields below" + driver.getTitle());
			  Thread.sleep(5000);
	}

	
	
	}

