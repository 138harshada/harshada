package com.utilityclasses;

public class coomonmethods {
	
	

}
