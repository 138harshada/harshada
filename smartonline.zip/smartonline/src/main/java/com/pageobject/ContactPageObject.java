package com.pageobject;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ContactPageObject {
	
	
	private WebElement contact;
	@FindBy(xpath = "//li[@id='menu-item-204']/a")
	private WebElement  contactslink;
	@FindBy(xpath = "//input[@id='input_29_19']")
	private WebElement firstname;
	@FindBy(xpath = "//input[@id='input_29_18']")
	private WebElement lastname;
	@FindBy(xpath = "//input[@id='input_29_7']")
	private WebElement email;
	@FindBy(xpath = "//input[@id='input_29_8']")
	private WebElement phone;
	@FindBy(xpath = "//textarea[@id='input_29_5']")
	private WebElement yourcomments;
	@FindBy(xpath = "//div[@class='recaptcha-checkbox-border']")
	private WebElement captcha;
	@FindBy(xpath = "//input[@id='gform_submit_button_29']")
	private WebElement submit;
	
	
	public void Clickoncontacts() {
		contactslink.click();}
		
	
	public String contactsheadertext() {
		String text = contactslink.getText();
		return text;}

	
	
		
		

	
	
	

}
		