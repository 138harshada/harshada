package com.testcases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.genericlibrary.Browser;
import com.genericlibrary.Propertiesfile;

public class HomepagenegativeTc {

	WebDriver driver;
	//GreatfinancewtPageObject greatfinacepage;

	@BeforeClass
	public void bfrcls() {
	driver= Browser.get_browser();
	}

	@BeforeMethod
	 public void bfrmtd() {
	driver.get(Propertiesfile.URL);;
	driver.manage().window().maximize();
	//greatfinacepage=PageFactory.initElements(driver, GreatfinancewtPageObject.class);
	}
	
	@Test()
	public void HomePageTC1() throws InterruptedException { 
		driver.findElement(By.xpath("//span[contains(text(),'Download your free guide to using a mortgage broke')]")).click();
		driver.findElement(By.name("input_7")).sendKeys("2690456");
		driver.findElement(By.name("input_2")).sendKeys("harshadasonawane138@gmail.com");
		driver.findElement(By.xpath("//input[@id='gform_submit_button_36']")).click();
		System.out.println("Page title is : The guide is on its way to your inbox." + driver.getTitle());
		  Thread.sleep(5000);	
	}
	
	@Test
	public void HomePageTC2() throws InterruptedException {
		driver.findElement(By.xpath("//span[contains(text(),'Download your free guide to using a mortgage broke')]")).click();
		driver.findElement(By.name("input_7")).sendKeys("2690456");
		driver.findElement(By.name("input_2")).sendKeys("abcgmail.com");
		driver.findElement(By.xpath("//input[@id='gform_submit_button_36']")).click();
		System.out.println("Page title is : There was a problem with your submission. Please review the fields below"+"The email address entered is invalid, please check the formatting" + driver.getTitle());
		  Thread.sleep(5000);		
	}
	
	@Test
	public void HomePageTC3() throws InterruptedException {
		driver.findElement(By.xpath("//span[contains(text(),'Download your free guide to using a mortgage broke')]")).click();
		driver.findElement(By.name("input_7")).sendKeys("2690456");
		driver.findElement(By.name("input_2")).sendKeys("abcgmail.com");
		driver.findElement(By.xpath("//input[@id='gform_submit_button_36']")).click();
		System.out.println("Page title is : The reCAPTCHA was invalid. Go back and try it again" + driver.getTitle());
		  Thread.sleep(5000);		
		
	}
	@Test
	public void HomePageTC4() throws InterruptedException {
		
		driver.findElement(By.xpath("//span[contains(text(),'Download your free guide to using a mortgage broke')]")).click();
		driver.findElement(By.name("input_7")).sendKeys("");
		driver.findElement(By.name("input_2")).sendKeys("");
		driver.findElement(By.xpath("//input[@id='gform_submit_button_36']")).click();
		System.out.println("Page title is : There was a problem with your submission. Please review the fields below" + driver.getTitle());
		  Thread.sleep(5000);		
		
	}
	
	@Test
	public void HomePageTC5() throws InterruptedException {
		
		driver.findElement(By.xpath("//span[text()='Speak to us today']")).click();
		driver.findElement(By.id("input_29_19")).sendKeys("123456");
		driver.findElement(By.id("input_29_18")).sendKeys("5689034");
		driver.findElement(By.id("input_29_7")).sendKeys("harshadasonawane138@gmail.com");
		driver.findElement(By.id("input_29_8")).sendKeys("abcdefg");
		driver.findElement(By.id("input_29_5")).sendKeys("heare your project");
		driver.findElement(By.id("gform_submit_button_29")).click();
		System.out.println("Page title is : There was a problem with your submission. Please review the fields below" + driver.getTitle());
		  Thread.sleep(5000);}
	
	@Test
	public void HomePageTC6() throws InterruptedException {
		
		driver.findElement(By.xpath("//span[text()='Speak to us today']")).click();
		driver.findElement(By.id("input_29_19")).sendKeys("123456");
		driver.findElement(By.id("input_29_18")).sendKeys("5689034");
		driver.findElement(By.id("input_29_7")).sendKeys("afg@23");
		driver.findElement(By.id("input_29_8")).sendKeys("abcdefg");
		driver.findElement(By.id("input_29_5")).sendKeys("heare your project");
		driver.findElement(By.id("gform_submit_button_29")).click();
		System.out.println("Page title is : There was a problem with your submission. Please review the fields below" + driver.getTitle());
		  Thread.sleep(5000);
	}
	
	@Test
	public void HomePageTC7() throws InterruptedException {
		
		driver.findElement(By.xpath("//span[text()='Speak to us today']")).click();
		driver.findElement(By.id("input_29_19")).sendKeys("harshada");
		driver.findElement(By.id("input_29_18")).sendKeys("sonawane");
		driver.findElement(By.id("input_29_7")).sendKeys("harshadasonawane138@gmail.com");
		driver.findElement(By.id("input_29_8")).sendKeys("9890470558");
		driver.findElement(By.id("input_29_5")).sendKeys("heare your project");
		driver.findElement(By.id("gform_submit_button_29")).click();
		System.out.println("Page title is : The reCAPTCHA was invalid. Go back and try it again" + driver.getTitle());
		  Thread.sleep(5000);
	}
		 		
	@Test
	public void HomePageTC8() throws InterruptedException {
		
		driver.findElement(By.xpath("//span[text()='Speak to us today']")).click();
		driver.findElement(By.id("input_29_19")).sendKeys("harshada");
		driver.findElement(By.id("input_29_18")).sendKeys("sonawane");
		driver.findElement(By.id("input_29_7")).sendKeys("harshadasonawane138@gmail.com");
		driver.findElement(By.id("input_29_8")).sendKeys("9890470558");
		driver.findElement(By.id("input_29_5")).sendKeys(" ");
		driver.findElement(By.id("gform_submit_button_29")).click();
		System.out.println("Page title is :There was a problem with your submission. Please review the fields below" + driver.getTitle());
		  Thread.sleep(5000);
	}
		 			

	
	@AfterTest
	public void terminateBrowser(){
	driver.close();
	}
}
