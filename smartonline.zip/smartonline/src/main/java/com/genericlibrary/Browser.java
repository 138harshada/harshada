package com.genericlibrary;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class Browser {

	public static WebDriver driver;
	public static WebDriver get_browser() {
		if(Propertiesfile.browser.equals("chrome"))
		{
			
			  driver=new ChromeDriver();
		}else if(Propertiesfile.browser.equals("firefox")){
			
			 driver=new FirefoxDriver();
		}
		else if(Propertiesfile.browser.equals("edge")){
			
			 driver=new EdgeDriver();
			
		} else if(Propertiesfile.browser.equals("IE")){
			
			 driver=new InternetExplorerDriver();
		}
		return driver;
	}
	
	
}
