package com.genericlibrary;

public interface Propertiesfile {
String browser="chrome";

String URL="https://master.staging-smartonline.com.au";

}
