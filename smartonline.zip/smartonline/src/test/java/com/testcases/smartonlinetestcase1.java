package com.testcases;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.genericlibrary.Browser;
import com.genericlibrary.Propertiesfile;
import com.genericlibrary.commonlibrary;
import com.pageobject.GreatfinancewtPageObject;

public class smartonlinetestcase1 extends commonlibrary {
	WebDriver driver;
	GreatfinancewtPageObject greatfinacepage;
	@BeforeClass
	public void bfrcls() {
		
	driver=	Browser.get_browser();
	}

@BeforeMethod
 public void bfrmtd() {
	driver.get(Propertiesfile.URL);;
	driver.manage().window().maximize();

	greatfinacepage=PageFactory.initElements(driver, GreatfinancewtPageObject.class);
}

@Test
public void smartonlinetest() {
String title=	gettitleofpages();
Assert.assertEquals(title,"Home - Great Finance");
greatfinacepage.clickonabout();
String abouttitle=	gettitleofpages();
Assert.assertEquals(abouttitle,"About - Great Finance");
greatfinacepage.clikonhomeloan();
String homeloantitle=	gettitleofpages();
Assert.assertEquals(homeloantitle,"Home Loans - Great Finance");
String headerhomeloan=greatfinacepage.homeloanheadertext();
Assert.assertEquals(headerhomeloan, "Home Loans");
greatfinacepage.Clickonbusinessloan();
String businessloantitle=	gettitleofpages();
Assert.assertEquals(businessloantitle,"Business Loans - Great Finance");
String headerbusinessloan=greatfinacepage.businessloneheadertext();
Assert.assertEquals(headerbusinessloan, "Business Loans"); 
greatfinacepage.Clickontestpageform();
String testpageformstitle=	gettitleofpages();
Assert.assertEquals(testpageformstitle,"Test page from Diana - Great Finance");
String headertestpageform=greatfinacepage.testpageheadertext();
Assert.assertEquals(headertestpageform, "Test page");
greatfinacepage.Clickoncalculator();
String calculatorstitle=	gettitleofpages();
Assert.assertEquals(calculatorstitle,"Calculators - Great Finance");
String headercalculators=greatfinacepage.calculatersheadertext();
Assert.assertEquals(headercalculators, "Calculators");
greatfinacepage.Clickonnews();
String newstitle=	gettitleofpages();
Assert.assertEquals(newstitle,"Newsfeed - Great Finance");

greatfinacepage.Clickoncontacts();
String contactstitle=	gettitleofpages();
Assert.assertEquals(contactstitle,"Contact - Great Finance");
String headercontacts=greatfinacepage.contactsheadertext();
Assert.assertEquals(headercontacts, "Contact");
	
}
@AfterMethod
public void aftmtd() {
	driver.close();
}
}
