package com.testcases;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.genericlibrary.Browser;
import com.genericlibrary.Propertiesfile;
import com.pageobject.GreatfinancewtPageObject;

public class Aboutpagetestcases {
	
	WebDriver driver;
	GreatfinancewtPageObject greatfinacepage;
	@BeforeClass
	public void bfrcls() {
		
	driver=	Browser.get_browser();
	}

@BeforeMethod
 public void bfrmtd() {
	driver.get(Propertiesfile.URL);;
	driver.manage().window().maximize();

	greatfinacepage=PageFactory.initElements(driver, GreatfinancewtPageObject.class);
}
@Test
public void Aboutpagetest() throws InterruptedException {
//About link
	driver.findElement(By.xpath("//li[@id='menu-item-102']")).click();
//click on contact us	
	driver.findElement(By.xpath("//span[normalize-space()='Contact us now']")).click();
	driver.navigate().forward();  
	driver.findElement(By.id("input_29_19")).sendKeys("harshada") ;
	driver.findElement(By.id("input_29_18")).sendKeys("sonawane");
	driver.findElement(By.id("input_29_7")).sendKeys("harshadasonawane138@gmail.com");
    driver.findElement(By.id("input_29_8")).sendKeys("9890470558");
    driver.findElement(By.id("input_29_5")).sendKeys("i am good");
    driver.findElement(By.xpath("//textarea[@id='input_29_5']")).click();
    driver.findElement(By.xpath("//input[@id='gform_submit_button_29']")).click();}

    // click on facebook   
@Test
public void Aboutpagefacebooktest() throws InterruptedException {
    WebElement ele = driver.findElement(By.xpath("//span[normalize-space()='Join us on Facebook']"));

	JavascriptExecutor jse = (JavascriptExecutor)driver;

	jse.executeScript("arguments[0].click()", ele);

	//Assert.assertTrue(ExpectedConditions.titleContains("AFGAustralianFinanceGroup").apply(driver).booleanValue());

	System.out.println("Page title is : " + driver.getTitle());

	driver.switchTo().defaultContent();

	Thread.sleep(3000);}
	
	

//clicking on twitter link
@Test
public void Aboutpagetwittertest() throws InterruptedException {
	WebElement st = driver.findElement(By.xpath("//span[normalize-space()='Join us on Twitter']"));

	JavascriptExecutor jse1 = (JavascriptExecutor)driver;

	jse1.executeScript("arguments[0].click()", st);

	System.out.println("Page title is : " + driver.getTitle());

	Thread.sleep(3000);}
	
	//close multiple windows and switch to parent window

/*	String originalHandle = driver.getWindowHandle();

	for(String handle : driver.getWindowHandles()) {

	if (!handle.equals(originalHandle)) {

	driver.switchTo().window(handle);

	driver.close();

	}

	}

	driver.switchTo().window(originalHandle);*/

	//meet the team scenarios
@Test
public void Aboutpagemeetteamtest() throws InterruptedException {
	driver.findElement(By.xpath("//li[@id='menu-item-102']")).click();

	Thread.sleep(4000);

	driver.findElement(By.xpath("(//h3[normalize-space()='Meet the team'])[1]")).click();

	Thread.sleep(4000);

	driver.findElement(By.xpath("//a[normalize-space()='08 9420 7001']")).click();

	Thread.sleep(4000);

	//driver.findElement(By.xpath("//*[@id=\"meet-the-team\"]/div[3]/div/div[2]/div/div[2]/div[2]/div/div/div[2]/div[2]/div[2]/div/div[3]/div[2]/a")).click();

	driver.findElement(By.xpath("(//a[@href='mailto:marketing@afgonline.com.au'][normalize-space()='marketing@afgonline.com.au'])[1]")).click();
	
	System.out.println("Page title is : " + driver.getTitle());

	System.out.println("Telephone and Mail Verified");

	try{

	driver.switchTo().alert();

	// If it reaches here, it found a popup

	} catch(NoAlertPresentException e){}
	
	driver.switchTo().defaultContent();

	Thread.sleep(3000);

	//Clicking on Download App
	
	////driver.findElement(By.xpath("//li[@id='menu-item-102']")).click();

	Thread.sleep(4000);
	
	String originalHandle1 = driver.getWindowHandle();

	for(String handle : driver.getWindowHandles()) {

	if (!handle.equals(originalHandle1)) {

	driver.switchTo().window(handle);

	driver.close();

	}

	}
	 

}
	
	
	

	
      
}
	



