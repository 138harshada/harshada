package com.testcases;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.genericlibrary.Browser;
import com.genericlibrary.Propertiesfile;



public class Homepagetestcases {
	
	    WebDriver driver;
		
		@BeforeClass
		public void bfrcls() {
			
		driver=	Browser.get_browser();
		}
	@BeforeMethod
	 public void bfrmtd() {
		driver.get(Propertiesfile.URL);;
		driver.manage().window().maximize();
		
	}
	@Test
	public void Homepagetest1() throws InterruptedException {
	
		driver.findElement(By.id("logo"));
//clicking on facebook link

		WebElement ele = driver.findElement(By.xpath("//i[@class='fa fa-facebook-square']"));

		JavascriptExecutor jse = (JavascriptExecutor)driver;

		jse.executeScript("arguments[0].click()", ele);

		//Assert.assertTrue(ExpectedConditions.titleContains("AFGAustralianFinanceGroup").apply(driver).booleanValue());

		System.out.println("Page title is : " + driver.getTitle());

		driver.switchTo().defaultContent();

		Thread.sleep(3000);
		
		

//clicking on twitter link

		WebElement st = driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[3]/div[1]/div[1]/div[1]/div[1]/div[3]/div[1]/div[2]/div[1]/div[2]/div[2]/div[1]/a[1]/i[1]"));

		JavascriptExecutor jse1 = (JavascriptExecutor)driver;

		jse1.executeScript("arguments[0].click()", st);

		System.out.println("Page title is : " + driver.getTitle());

		Thread.sleep(3000);
		
		

//clicking on 'Download your free guide to using a mortgage broker'	
	driver.findElement(By.xpath("//span[contains(text(),'Download your free guide to using a mortgage broke')]")).click();
	driver.findElement(By.name("input_7")).sendKeys("harshada");
	driver.findElement(By.name("input_2")).sendKeys("harshadasonawane138@gmail.com");
	driver.findElement(By.xpath("//textarea[@id='input_29_5']")).click();
	driver.findElement(By.xpath("//input[@id='gform_submit_button_36']")).click();
 		
	
		
	/*	driver.findElement(By.xpath("//h1[normalize-space()='Get started with our free guides.']")).click();
		driver.findElement(By.xpath("//h3[normalize-space()='Investing in property']"));
		driver.findElement(By.xpath("//a[@href='/investing-in-property-guide/']//span[contains(text(),'Download Your Free Guide')]")).click();
		driver.findElement(By.xpath("//span[normalize-space()='Speak to us today']")).click();  */
	}
	
	
}
